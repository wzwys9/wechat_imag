import hashlib
import time
import os
import uuid
import requests
import xml.etree.ElementTree as ET
from flask import Flask, request, make_response

app = Flask(__name__)

# 配置项 - 从环境变量读取
TOKEN = os.environ.get('WECHAT_TOKEN', 'your_token_here')
DOMAIN = os.environ.get('DOMAIN', 'https://your-domain.com')
UPLOAD_DIR = '/app/uploads'

# 确保上传目录存在
os.makedirs(UPLOAD_DIR, exist_ok=True)


def check_signature(signature, timestamp, nonce):
    """验证微信服务器签名"""
    tmp_list = sorted([TOKEN, timestamp, nonce])
    tmp_str = ''.join(tmp_list)
    tmp_str = hashlib.sha1(tmp_str.encode('utf-8')).hexdigest()
    return tmp_str == signature


def parse_xml(xml_data):
    """解析微信XML消息"""
    root = ET.fromstring(xml_data)
    msg = {}
    for child in root:
        msg[child.tag] = child.text
    return msg


def make_text_response(to_user, from_user, content):
    """生成文本回复XML"""
    return f"""<xml>
<ToUserName><![CDATA[{to_user}]]></ToUserName>
<FromUserName><![CDATA[{from_user}]]></FromUserName>
<CreateTime>{int(time.time())}</CreateTime>
<MsgType><![CDATA[text]]></MsgType>
<Content><![CDATA[{content}]]></Content>
</xml>"""


def download_image(pic_url, media_id):
    """下载图片并保存"""
    try:
        response = requests.get(pic_url, timeout=30)
        if response.status_code == 200:
            # 生成唯一文件名
            ext = '.gif' if 'gif' in response.headers.get('Content-Type', '') else '.png'
            filename = f"{media_id}_{uuid.uuid4().hex[:8]}{ext}"
            filepath = os.path.join(UPLOAD_DIR, filename)

            with open(filepath, 'wb') as f:
                f.write(response.content)

            return filename
    except Exception as e:
        print(f"下载图片失败: {e}")
    return None


@app.route('/wechat', methods=['GET', 'POST'])
def wechat():
    # GET请求 - 微信服务器验证
    if request.method == 'GET':
        signature = request.args.get('signature', '')
        timestamp = request.args.get('timestamp', '')
        nonce = request.args.get('nonce', '')
        echostr = request.args.get('echostr', '')

        if check_signature(signature, timestamp, nonce):
            return echostr
        return 'Verification failed'

    # POST请求 - 接收消息
    xml_data = request.data
    msg = parse_xml(xml_data)

    msg_type = msg.get('MsgType', '')
    from_user = msg.get('FromUserName', '')
    to_user = msg.get('ToUserName', '')

    # 处理图片消息（表情包也是图片消息）
    if msg_type == 'image':
        pic_url = msg.get('PicUrl', '')
        media_id = msg.get('MediaId', '')

        if pic_url:
            filename = download_image(pic_url, media_id)
            if filename:
                download_url = f"{DOMAIN}/download/{filename}"
                reply_content = f"表情包下载链接：\n{download_url}"
            else:
                reply_content = "抱歉，保存图片失败，请重试"
        else:
            reply_content = "无法获取图片"
    else:
        reply_content = "发送表情包或图片给我，我会返回下载链接~"

    response = make_response(make_text_response(from_user, to_user, reply_content))
    response.content_type = 'application/xml'
    return response


@app.route('/download/<filename>')
def download(filename):
    """提供图片下载"""
    from flask import send_from_directory
    return send_from_directory(UPLOAD_DIR, filename)


@app.route('/health')
def health():
    """健康检查"""
    return 'OK'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
