# 微信公众号表情包下载器

发送表情包/图片到公众号，自动返回下载链接。

## 快速部署

### 1. 修改配置

编辑 `docker-compose.yml`，修改以下配置：

```yaml
environment:
  - WECHAT_TOKEN=你的Token          # 自定义一个Token
  - DOMAIN=https://你的域名          # 你的服务器域名
```

### 2. 启动服务

```bash
docker-compose up -d --build
```

### 3. 配置微信公众号

登录 [微信公众平台](https://mp.weixin.qq.com/)：

1. 进入 **设置与开发** -> **基本配置**
2. 在服务器配置中填写：
   - URL: `https://你的域名/wechat`
   - Token: 与 docker-compose.yml 中的 WECHAT_TOKEN 保持一致
   - EncodingAESKey: 随机生成即可
   - 消息加解密方式: 明文模式
3. 点击 **启用**

### 4. Nginx 反向代理（可选）

如果使用 Nginx，添加以下配置：

```nginx
server {
    listen 443 ssl;
    server_name 你的域名;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 常用命令

```bash
# 查看日志
docker-compose logs -f

# 重启服务
docker-compose restart

# 停止服务
docker-compose down
```

## 注意事项

- 图片保存在 `./uploads` 目录
- 定期清理旧图片以节省空间
- 建议配置 HTTPS（微信要求）
